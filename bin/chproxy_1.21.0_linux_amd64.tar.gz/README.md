[![Go Report Card](https://goreportcard.com/badge/github.com/ContentSquare/chproxy)](https://goreportcard.com/report/github.com/ContentSquare/chproxy)
[![Build Status](https://travis-ci.org/ContentSquare/chproxy.svg?branch=master)](https://travis-ci.org/ContentSquare/chproxy?branch=master)
[![Coverage](https://img.shields.io/badge/gocover.io-75.7%25-green.svg)](http://gocover.io/github.com/ContentSquare/chproxy?version=1.9)

# chproxy

Chproxy is an HTTP proxy and load balancer for the [ClickHouse](https://ClickHouse.yandex) database.

It is an open-source community project and not an official ClickHouse project.

Full documentation is available on [the official website](https://www.chproxy.org/).

## Contributing

See our [contributing guide](./CONTRIBUTING.md)
